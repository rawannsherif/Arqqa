<?php
define('__ROOT__', "../app/");
require_once(__ROOT__ . "model/User.php");
require_once(__ROOT__ . "controller/userController.php");
require_once(__ROOT__ . "view/ViewEmployee.php");

$model = new User();
$controller = new userController($model);
$view = new ViewEmployee($controller, $model);

if (isset($_GET['action']) && !empty($_GET['action'])) {
	switch($_GET['action']){
		case 'login':
			echo $model->login($_POST["username"],$_POST["password"]);
			break;
		
	}
}

?>


<html>
<head>
<link href="style.css" rel="stylesheet" type="text/css">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
	
	<div class='page'>
	<div>
	
	   <img src="Component 212 – 1.png" width="750" height="740"><br><br><br><br>
	   
     </div>
	 
	<div style='    margin-top: 200px;
    margin-left: 16px;'>
	<div>
	
	<div>
	<img style='position: relative;left: 175;'src="logo.png" width="138" height="171"> 
	
     <br><br>
		<p>welcome back!please log to your account</p>
	 <br><br>
     </div>
	 
	
	<div style="text-align-last: center;">
	 <form method="post" action="login.php?action=login">
        <label for="name" class="label">UserName:</label>
        <input type="text" name="username" id="username" class="input"><br><br>
        <label for="pass" class="label">Password:</label>
        <input type="password" name="password" id="password" class="input"><br><br>
	</div>
		<div style='text-align: center;'>
		<div><input type="checkbox" name="name">
        <label class='title1'
for="name">Remember me</label>
        
		</div>
        <a class='title1'href="Email-changePass.php">Forgot Password</a><br>
</div>
 <div style='text-align: center;'> <input class='button'type="submit" name="submit" value="Login">
</div>
</form>
		</div>
		</div>
    </body>
</html>