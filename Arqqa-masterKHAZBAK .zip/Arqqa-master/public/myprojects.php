

<body  background='background.png'>
<html>
	<head>
		<link href="style.css" rel="stylesheet" type="text/css">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"> </script>
		
	</head>



	<body >


		
		<a href='myprojects.php?action=logout'>
		
			<button  style=' position: relative;bottom: 34px;left: 1320px;'class='logout'  name = "logout"> Log Out </button>
			
		</a>
		
		<?php
define('__ROOT__', "../app/");
require_once(__ROOT__ . "model/UserProjects.php");
require_once(__ROOT__ . "controller/userController.php");
require_once(__ROOT__ . "view/viewUser.php");

$model = new UserProjects();
$controller = new userController($model);
$view = new viewUser($controller, $model);


if (isset($_GET['action']) && !empty($_GET['action'])) {
	switch($_GET['action']){
		case 'feedbacks':
			echo $view->Feedback();
			break;
		case'logout':
			session_destroy();
			header("Location:login.php");
			break;
		
		
	}
}
else
	
		echo $view->output();

?>


	</body>
</html>