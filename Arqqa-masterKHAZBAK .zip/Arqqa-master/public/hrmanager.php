
<html>
	<head>
		<link href="style.css" rel="stylesheet" type="text/css">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"> </script>
		
		

	</head>


 

	<body  background='background.png'>
		<div>
			<a href="login.php"><button class="logout" name="logout" style="position: relative;left: 1185;">log out</button></a>
		</div>

		<div class="topnav">
		
			<button class="activebutton" name="viewemp">View Employees</button>
			<a href="feedbacks.php"><button class="buttonnav" name="feedback">Feedback</button></a>
			<a href="requests.php"><button class="buttonnav" name="requests" onclick="requests.html" >Requests</button></a>
		</div>


		<h3 class='navtitle'>Employees:</h3>
		<br/>

		<input class="search" type="text" placeholder="Search" name="search" style="bottom: 92px;position: relative;left: 800;">
		
		
		<?php

define('__ROOT__', "../app/");
require_once(__ROOT__ . "model/HR.php");
require_once(__ROOT__ . "controller/HRController.php");
require_once(__ROOT__ . "view/ViewHR.php");

$model = new HR();
$controller = new HRController($model);
$view = new ViewHR($controller, $model);

if (isset($_GET['action']) && !empty($_GET['action'])) {
	switch($_GET['action']){
		case 'insert':
			
			echo $view->addform();
			break;
		case 'edit':
			echo $view->editform($_GET['id']);
			break;
		case 'view':
			echo $view->view($_GET['id']);
			break;
		case 'editAction':
			$controller->edit($_GET['id']);
			echo $view->output();
			break;
		case 'remove':
			$controller->deactivate($_GET['id']);
			echo $view->output();
			break;
		case'back':
			echo $view->output();
			break;
		case 'insertAction':
		$controller->insert();
			echo $view->output();
			break;
		case 'overtime':
			echo $view->overtime($_GET['id']);
			break;
		
		
	}
}
else
	
		echo $view->output();
	
 
?>
		
		
		
		
		
		<a href='hrmanager.php?action=insert'>
		<button type='button' class='addbutton'>Add Employee</button></a>
	</body>
</html>