
		

<html>
	<head>
		<link href="style.css" rel="stylesheet" type="text/css">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<script>

			function myFunction() {

			var s = document.getElementById("feedbackdiv");
			if (s.style.display === "none") {
				s.style.display = "block";
			} 
			}
			function myFunction2() {
			var h = document.getElementById("feedbackdiv");
			if (h.style.display === "block") {
				h.style.display = "none";
			} 
			}
		</script>
		<script>
			var slider = document.getElementById("myRange");
			var output = document.getElementById("demo");
			output.innerHTML = slider.value;
			slider.oninput = function() {
			output.innerHTML = this.value;
			}
		</script>
	
	</head>

	<body background="background.png">
		<div>
			<a href="login.php"><button class="logout" name="logout" style="position: relative;bottom: 0px;left: 1318px;">log out</button></a>
		</div>

		<div class="navbarhrm">
			<a href='hrmanager.php'><button class="buttonnav" name="viewemp">View Employees</button></a>
			<a href='feedbacks.php'><button class="activebutton" name="feedback">Feedback</button></a>
			<a href='requests.php'><button class="buttonnav" name="requests">Requests</button></a>
		</div>
		<input class="search" type="text" placeholder="Search" name="search" style="position: relative;bottom: 40px;left: 936px;">


<?php
define('__ROOT__', "../app/");
require_once(__ROOT__ . "model/Feedbacks.php");
require_once(__ROOT__ . "controller/FeedbackController.php");
require_once(__ROOT__ . "view/viewFeedback.php");

$model = new Feedbacks();
$controller = new FeedbackController($model);
$view = new viewFeedback($controller, $model);

if (isset($_GET['action']) && !empty($_GET['action'])) {
	switch($_GET['action']){
		case 'view':
			
			echo $view->feedbackview($_GET['id']);
			break;
		
		
}}
else
	
		echo $view->output();
	
 
?>


		

		<div class='div' id='feedbackdiv' style="display : none;">
			<div style="position: relative;left: 81px;top: 110px;">
			
				<label class="labelfeedback">Feedback</label>
				<div class="print" >
				</div>
			</div>
			
			<h3 class="feedbackdiv">performance rating:</h3>
				<div class="slidecontainerfeedbacks" style=''>
					<input type="range" min="1" max="10" value="5" class="slider" id="myRange">
					<p style='position: relative;top: 270px;'>Value: <span id="demo"></span></p>
				</div>
			<button type="button" onclick="myFunction2()"class='back'>Back</button>
		</div>
	</body>

</html>