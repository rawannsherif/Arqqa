<html>
	<head>
		<link href="style.css" rel="stylesheet" type="text/css">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
	</head>

	<body background="background.png">
		<div>
			<a href="login.php>"<button class="logout" name="logout" style="position: relative;left: 1185;">log out</button></a>
		</div>

		<div>
			<a href='hrmanager.php'><button class="buttonnav" name="viewemp">View Employees</button></a>
			<a href='feedbacks.php'><button class="buttonnav" name="feedback">Feedback</button></a>
			<a href='requests.php'><button class="activebutton" name="requests">Requests</button></a>
		</div>


		<h3 class='navtitle'>Requests:</h3>


		<input class="search" type="text" placeholder="Search" name="search" style="bottom: 92px;position: relative;left: 800;">

		<form name="request" method = "POST" action ="" >
			<div class="containerRequests" style="text-align: center;">
				<div style="">
			
					<label class="textRequest">Approval Needed:</label><br>
					<label class="textRequest"> Data<label><br>
					<div style="position: relative;top: 44px;    text-align: left;"><label class="textRequest" > Requested By</label>
					</div>

				<div>
					<button class="approve" type="submit" name="Accept">Accept</button>
					<button class="decline" type="submit" name="decline">Decline</button>
				</div>
				</div>

			</div>
		</form>

  



	</body>
</html>