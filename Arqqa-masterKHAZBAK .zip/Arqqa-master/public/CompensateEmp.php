 <html>
 
 <body  background="background.png">
 <?php
 define('__ROOT__', "../app/");
require_once(__ROOT__ . "model/CompensateEMP.php");
require_once(__ROOT__ . "controller/CompensateEmpController.php");
require_once(__ROOT__ . "view/viewCompensateEmp.php");

$model = new CompensateEmp();
$controller = new CompensateEmpController($model);
$view = new viewCompensateEmp($controller, $model);

if (isset($_GET['action']) && !empty($_GET['action'])) {
	switch($_GET['action']){
		case 'overtime':
			
			echo $view->output();
			break;
		
		
	}
}
else
	
		echo $view->output();
	
 
?>
 
 </html>
 