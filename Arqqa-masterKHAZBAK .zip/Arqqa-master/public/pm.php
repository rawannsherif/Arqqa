<html>
<head>
<link href="stylekhazbak.css" rel="stylesheet" type="text/css">

<script>

function editselectemployee() {

  var s = document.getElementById("p-div");
  if (s.style.display === "none") {
    s.style.display = "block";
  }
}
function hideeditselectemployee() {
  var h = document.getElementById("p-div");
  if (h.style.display === "block") {
    h.style.display = "none";

  }
}



</script>
</head>
<body background='background.png'>
<?php
define('__ROOT__', "../app/");
require_once('C:/wamp64\www/Arqqa-master/app/view/viewpm.php');
require_once(__ROOT__ . "model/projects.php");
require_once(__ROOT__ . "controller/pmcontroller.php");

$model= new projects();
$controller=new pmcontroller($model);
$view = new viewpm($controller,$model);

if (isset($_GET['action']) && !empty($_GET['action'])) {
  if($_GET['action'] == "ediit"){
	echo '<script>alert('.$_GET['name'].');</script>';

    echo $view->editproject($_GET['name']);

  }
	else if($_GET['action'] =='delete'){
		$controller->delete();
	}
	else if($_GET['action'] == "deleteuser"){

    echo $controller->{$_GET['action']}();
  }
	else if($_GET['action'] == "insert"){

  echo $view->addproject();
  }
  else if($_GET['action'] == "view"){
    echo '<script>alert('.$_GET['name'].');</script>';

  echo $view->viewproject($_GET['name']);
  }
}
else if(isset($_POST['confirmedit'])){
	$controller->edit();
}
else if(isset($_POST['confirmadd'])){
	$controller->insert();
}
else{
  require_once("C:/wamp64/www/Arqqa-master/public/pmheader.html");

    echo $view->output();
}

?>
</body>
</html>
