<html>
	<head>
		<link href="style.css" rel="stylesheet" type="text/css">
	</head>
	
	<body background='background.png'>
		<?php
		define('__ROOT__', "../app/");
		require_once(__ROOT__ . "model/Projects.php");
		require_once(__ROOT__ . "controller/Projectcontroller.php");
		require_once(__ROOT__ . "view/viewProjects.php");
		
		$model= new Projects();
		$controller=new Projectcontroller($model);
		$view = new viewProjects($controller,$model);

		if (isset($_GET['action']) && !empty($_GET['action'])) {
	switch($_GET['action']){
		case 'insert':
			
			echo $view->addproject();
			break;
		case 'edit':
			echo $view->editproject($_GET['name']);
			break;
		case 'view':
			echo $view->view($_GET['id']);
			break;
		case 'editAction':
			$controller->edit($_GET['name']);
			echo $view->output();
			break;
		case 'remove':
			$controller->deactivate($_GET['id']);
			echo $view->output();
			break;
		case'back':
			echo $view->output();
			break;
		case 'insertAction':
		$controller->insert();
			echo $view->output();
			break;
		case 'overtime':
			echo $view->overtime($_GET['id']);
			break;
		
		
		
	}
}
else
	
		echo $view->output();
	
		?>
