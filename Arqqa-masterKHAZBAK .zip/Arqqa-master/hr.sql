-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 05, 2020 at 09:18 PM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.1.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hr`
--

-- --------------------------------------------------------

--
-- Table structure for table `bonus`
--

CREATE TABLE `bonus` (
  `emp_id` int(11) NOT NULL,
  `emp_performance` int(11) NOT NULL,
  `average` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bonus`
--

INSERT INTO `bonus` (`emp_id`, `emp_performance`, `average`) VALUES
(1, 7, 0.2);

-- --------------------------------------------------------

--
-- Table structure for table `compensation_plan`
--

CREATE TABLE `compensation_plan` (
  `id` int(11) NOT NULL,
  `weekend_rate` float NOT NULL,
  `nightshift_rate` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `compensation_plan`
--

INSERT INTO `compensation_plan` (`id`, `weekend_rate`, `nightshift_rate`) VALUES
(101, 2, 1.5);

-- --------------------------------------------------------

--
-- Table structure for table `comp_emp`
--

CREATE TABLE `comp_emp` (
  `comp_id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `pos_salary` int(11) NOT NULL,
  `weekend_Overtime` float NOT NULL,
  `nightshift_overtime` float NOT NULL,
  `total` float NOT NULL,
  `bonus_avg` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `comp_emp`
--

INSERT INTO `comp_emp` (`comp_id`, `emp_id`, `pos_salary`, `weekend_Overtime`, `nightshift_overtime`, `total`, `bonus_avg`) VALUES
(101, 1, 7000, 6, 0, 0, 0.2);

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `id` int(11) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `position` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `mobile` int(11) NOT NULL,
  `img` varchar(255) NOT NULL,
  `deactivate` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `fullname`, `address`, `email`, `position`, `username`, `password`, `mobile`, `img`, `deactivate`) VALUES
(1, 'mayar osama fouad', 'elrehab', 'mayar@gmail.com', 1, 'mayar', '1234', 961246823, 'background.png', 0),
(2, 'rawan sherif', 'masr el-gdeeda', 'rawansherif@gmail.com', 2, 'rawan', '1234', 19799302, 'logo.png', 0),
(3, 'mohamed hassan', 'el tagmo3', 'mohamed@gmail.com', 3, 'khazbak', '1234', 252466, '', 0),
(4, 'john hany', 'el sherouk', 'john@gmail.com', 4, 'john', '1234', 89362959, '', 0),
(9, 'reem', 'elrehab', 'reem@gmail.com', 3, 'reem', '1234', 142432543, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `mngID` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `p_name` varchar(255) NOT NULL,
  `feedback` varchar(255) NOT NULL,
  `performance` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`mngID`, `id`, `p_name`, `feedback`, `performance`) VALUES
(3, 4, 'it', 'good', 6),
(9, 2, 'hr', 'not good', 5),
(1, 1, 'commercial', 'good', 7);

-- --------------------------------------------------------

--
-- Table structure for table `positiontype`
--

CREATE TABLE `positiontype` (
  `id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `salary` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `positiontype`
--

INSERT INTO `positiontype` (`id`, `type`, `salary`) VALUES
(1, 'Hr Manager', 7000),
(2, 'HR Employee', 9000),
(3, 'Project Manager', 8000),
(4, 'Employee', 60000);

-- --------------------------------------------------------

--
-- Table structure for table `project`
--

CREATE TABLE `project` (
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `mng_id` int(11) NOT NULL,
  `startDate` date NOT NULL,
  `endDate` date NOT NULL,
  `noOfemp` int(11) NOT NULL,
  `state_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `project`
--

INSERT INTO `project` (`name`, `description`, `mng_id`, `startDate`, `endDate`, `noOfemp`, `state_id`) VALUES
('commercial', 'commercial for CIB', 1, '2020-05-02', '2020-05-30', 2, 100),
('MIU', 'attendance system', 1, '2020-05-10', '2020-05-22', 3, 1),
('miuu', 'attendance system', 1, '2020-12-01', '2022-01-01', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `proj_state`
--

CREATE TABLE `proj_state` (
  `id` int(11) NOT NULL,
  `state` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `proj_state`
--

INSERT INTO `proj_state` (`id`, `state`) VALUES
(100, 'active');

-- --------------------------------------------------------

--
-- Table structure for table `request`
--

CREATE TABLE `request` (
  `hr_id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  `state` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `request_type`
--

CREATE TABLE `request_type` (
  `id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `request_type`
--

INSERT INTO `request_type` (`id`, `type`) VALUES
(1, 'add'),
(2, 'edit'),
(3, 'deactivate');

-- --------------------------------------------------------

--
-- Table structure for table `task`
--

CREATE TABLE `task` (
  `id` int(11) NOT NULL,
  `p_name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `assigned` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `task_emp`
--

CREATE TABLE `task_emp` (
  `task_id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `mng_id` int(11) NOT NULL,
  `state` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `works_on`
--

CREATE TABLE `works_on` (
  `emp_id` int(11) NOT NULL,
  `p_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `works_on`
--

INSERT INTO `works_on` (`emp_id`, `p_name`) VALUES
(4, 'commercial'),
(4, 'MIU');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bonus`
--
ALTER TABLE `bonus`
  ADD PRIMARY KEY (`emp_id`,`emp_performance`);

--
-- Indexes for table `compensation_plan`
--
ALTER TABLE `compensation_plan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comp_emp`
--
ALTER TABLE `comp_emp`
  ADD PRIMARY KEY (`comp_id`,`emp_id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `project`
--
ALTER TABLE `project`
  ADD PRIMARY KEY (`name`);

--
-- Indexes for table `works_on`
--
ALTER TABLE `works_on`
  ADD PRIMARY KEY (`emp_id`,`p_name`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
