<?php
  require_once(__ROOT__ . "model/Model.php");
?>

<?php
class Employee extends Model {
    private $id;
    private $username;
	private $password;
	//private $acctype;

    private $mobile;

  function __construct($id="",$username="",$address="",$email="",$position="",$fullname="",$password="",$mobile="",$img="",$deactivate="") {

	    $this->db = $this->connect();

    if(""===$username){
      $this->readUser($id);
    }else{
      $this->username = $username;
	  $this->password=$password;
      //$this->acctype=$acctype;
     $this->mobile = $mobile;
    }
  }

  function getName() {
    return $this->username;
  }
  function setName($username) {
    return $this->username = $username;
  }

   function getPassword() {
    return $this->password;
  }
  function setPassword($password) {
    return $this->password = $password;
  }

  function getAge() {
    return $this->age;
  }
  function setAge($age) {
    return $this->age = $age;
  }

  function getPhone() {
    return $this->mobile;
  }
  function setPhone($phone) {
    return $this->phone = $phone;
  }

  function getID() {
    return $this->id;
  }
function getPos(){



}
  function Login($username,$password){

	$sql="SELECT * FROM employee WHERE username='$username' AND password='$password' AND deactivate='0'";
	$db = $this->connect();
    $result = $db->query($sql);
    if ($result->num_rows == 1){
		$row = $db->fetchRow();
		echo "<script>alert('Logged in Successfully');</script>";
		$this->acctype = $row['position'];
		if( $this->acctype == '2'){
			echo '<script>window.location.href= "hrmanager.php";</script>';
		}
		else if($this->acctype=='1' ){
			echo '<script>window.location.href= "requests.php";</script>';
		}
		else if($this->acctype=='3' ){
			echo '<script>window.location.href= "Projectmanager.php";</script>';
		}
		else{
			echo '<script>window.location.href= "myprojects.php";</script>';
		}
	}

	else
	{
		echo "<script>alert('Wrong username or password.');</script>";
	}
}


  function readEmployee($id){
    $sql = "SELECT * FROM employee where ID=".$id;
    $db = $this->connect();
    $result = $db->query($sql);
    if ($result->num_rows == 1){
        $row = $db->fetchRow();
        $this->username = $row["username"];
		$_SESSION["username"]=$row["username"];
		$this->password=$row["Password"];

		$this->mobile = $row["mobile"];
    }
    else {
        $this->username = "";
		$this->password="";

		$this->mobile = "";
    }
  }

  function editEmployee($username, $password,  $mobile){
      $sql = "update employee set username='$usernaname',password='$password', mobile='$mobile' where id=$this->id;";
        if($this->db->query($sql) === true){
            echo "updated successfully.";
            $this->readEmployee($this->id);
        } else{
            echo "ERROR: Could not able to execute $sql. " . $conn->error;
        }

  }

  function deleteEmployee(){
	  $sql="delete from employee where id=$this->id;";
	  if($this->db->query($sql) === true){
            echo "deletet successfully.";
        } else{
            echo "ERROR: Could not able to execute $sql. " . $conn->error;
        }
	}

}
