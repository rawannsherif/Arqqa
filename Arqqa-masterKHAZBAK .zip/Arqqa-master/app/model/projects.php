<?php
require_once("C:\wamp64\www\Arqqa-master\app\model\Model.php");
require_once("C:\wamp64\www\Arqqa-master\app\model\project.php");
require_once("C:\wamp64\www\Arqqa-master\app\model\Employee.php");
class Projects extends Model {
	private $projects;

	function __construct() {
		$this->fillArray();
		$this->fillArraye();
	}

	function fillArray() {
		$this->projects = array();
		$this->db = $this->connect();
		$result = $this->readProjects();
		while ($row = $result->fetch_assoc()) {
			array_push($this->projects, new project($row["name"],$row["description"],$row["mng_id"],$row["startDate"],$row["endDate"],$row["noOfemp"],$row["state_id"]));
		}
	}

	function getProjects() {
			$this->fillArray();
		return $this->projects;
	}

	function getProject($projectname) {
		foreach($this->projects as $project) {
			if ($projectname == $project->getName()) {
				return $project;
			}
		}
	}

	function readProjects(){
		$sql = "SELECT * FROM project where state_id !=2";

		$result = $this->db->query($sql);
		if ($result->num_rows > 0){
			return $result;
		}
		else {
			return false;
		}
	}

	function insertProject($name, $description, $mngid, $startDate,$endDate,$noOfemp,$stateid){
		$sql = "INSERT INTO project (name, description,mng_id,startDate,endDate,noOfemp,state_id) VALUES ('$name', '$description', '$mngid', '$startDate','$endDate','$noOfemp','$stateid')";
		if($this->db->query($sql) === true){
			echo "Records inserted successfully.";
			$this->fillArray();
			echo '<script>window.location.href= "pm.php";</script>';
		}
		else{
			echo "ERROR: Could not able to execute $sql. " . $conn->error;
		}
	}
	function  editProject($id,$name, $description, $mngid, $startDate,$endDate,$noOfemp="",$stateid=""){
			$sql = "UPDATE project set name='$name',description='$description', mng_id=$mngid, startDate='$startDate', endDate='$endDate', noOfemp=$noOfemp, state_id=$stateid where name='$id' ";
				if($this->db->query($sql) === true){
						echo "updated successfully.";
					  echo '<script>window.location.href= "pm.php";</script>';
				} else{
				echo "ERROR: Could not able to execute $sql. " . $conn->error;
				}

	}
	function deleteProject($name){
		$sql="UPDATE project set state_id=2 where name='$name'";
		if($this->db->query($sql) === true){
						echo "deletet successfully.";
						 echo '<script>window.location.href= "pm.php";</script>';
				} else{
						echo "ERROR: Could not able to execute $sql. " . $conn->error;
				}
	}
	function fillArraye() {
		$this->employees= array();
		$this->db = $this->connect();
		$result = $this->readEmployees();
		while ($row = $result->fetch_assoc()) {
			array_push($this->employees, new Employee($row['id'],$row["username"],$row["address"],$row["email"],$row["position"],$row["fullname"],$row["password"],$row["mobile"],$row["img"],$row["deactivate"]));
		}
	}

	function readEmployees() {
    $sql = "SELECT * FROM employee";

    $result = $this->db->query($sql);
    if ($result->num_rows > 0){
      return $result;
    }
    else {
      return false;
    }
	}
  function getEmployees() {
			$this->fillArraye();
		return $this->employees;
	}
}

?>
