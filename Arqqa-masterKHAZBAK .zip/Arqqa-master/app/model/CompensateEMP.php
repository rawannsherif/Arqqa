<?php
require_once(__ROOT__ . "model/Model.php");
require_once(__ROOT__ . "model/Employee.php");

class CompensateEMP extends Model {
   // $emp= new Employee();
    protected $comp_id;
    protected $emp_id=1;
    protected $bonus_avg;
    protected $pos_salary;
    protected $weeknd_overtime;
    protected $nightshift_overtime;
    protected $total;
	protected $Employees;

    function __construct($emp_id="",$comp_id="",$bonus_avg="",$pos_salary="",$weeknd_overtime="",$nightshift_overtime="",$total="") {
        $this->emp_id = 1;
        $this->db = $this->connect();

        if(""===$emp_id){
            $this->readCompPlan($emp_id);
        }
        else{
            $this->weeknd_overtime = $weeknd_overtime;
            $this->nightshift_overtime=$nightshift_overtime;
            $this->total = $total;
        }
    }

    function getWeekndover(){
        return $this->weeknd_overtime;
    }
    function setWeekndover($weeknd_overtime){
        return $this->weeknd_overtime=$weeknd_overtime;
    }
    function getNightshiftover(){
        return $this->nightshift_overtime;
    }
    function setNightshiftover($nightshift_overtime){
        return $this->nightshift_overtime=$nightshift_overtime;
    }
    function getTotal(){
        return $this->total;
    }
    function setTotal($total){
        return $this->total=$total;
    }
    
    function readCompPlan($emp_id){
        $sql = "SELECT * FROM comp_emp where emp_id=".$emp_id;
        $db = $this->connect();
        $result = $db->query($sql);
        if ($result == true){
            $row = $db->fetchRow();
            $this->bonus_avg = $row["bonus_avg"];
            $this->weeknd_overtime=$row["weekend_Overtime"];
            $this->nightshift_overtime=$row["nightshift_overtime"];
            $this->total=$row["total"];
        }
        else {
            $this->emp_id = "";
            $this->bonus_avg="";
            $this->weeknd_overtime="";
            $this->nightshift_overtime="";
            $this->total="";
            }
    }

    
}
