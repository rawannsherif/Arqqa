<?php 
require_once(__ROOT__ . "model/Model.php");

class CompensationPlan extends Model{
    protected $id;
    protected $weekend_rate;
    protected $nightshift_rate;

    function __construct($id) {
        $this->id = $id;        
        $this->db = $this->connect();

        if(""===$id){
            $this->readCompPlan($id);           
        }
        else{
            $this->weekend_rate = $weekend_rate;
            $this->nightshift_rate=$nightshift_rate;            
        }
    }
    
    function getID(){
        return $this->id;
    }
    function getWeeknd(){
        return $this->weekend_rate;
    }
    function getNightshift(){
        return $this->nightshift_rate;
    }

    function readCompPlan($id){
        $sql = "SELECT * FROM compensation_plan where id=".$id;
        
        $db = $this->connect();
        $result = $db->query($sql);
        if ($result == true){
            $row = $db->fetchRow();
            $this->weekend_rate = $row["Weekend_Rate"];
            $this->nigthshift_rate=$row["Nightshift_Rate"];
        }
        else {
            $this->weekend_rate = "";
            $this->nightshift_rate="";
        }
    }
}