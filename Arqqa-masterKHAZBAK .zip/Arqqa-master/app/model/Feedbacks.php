<?php
require_once(__ROOT__ . "model/Model.php");
require_once(__ROOT__ . "model/Feedback.php");

class Feedbacks extends Model {
	private $feedbacks;
	function __construct() {
		$this->fillArray();
	}

	function fillArray() {
		$this->feedbacks = array();
		$this->db = $this->connect();
		$result = $this->readFeedbacks();
		while ($row = $result->fetch_assoc()) {
			array_push($this->feedbacks, new Feedback($row["id"]));
		}
	}

	function getFeedbacks() {
		$this->fillArray();  
		return $this->feedbacks;
	}


	function readFeedbacks(){
		$sql = "SELECT * FROM feedback";
		$result = $this->db->query($sql);
		if ($result->num_rows > 0){
			return $result;
		}
		else {
			return false;
		}
	}

	
}