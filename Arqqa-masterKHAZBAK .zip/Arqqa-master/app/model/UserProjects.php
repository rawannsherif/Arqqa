<?php
require_once(__ROOT__ . "model/Model.php");
require_once(__ROOT__ . "model/UserProject.php");

class UserProjects extends Model {
	private $userprojects;
	function __construct() {
		$this->fillArray();
	}

	function fillArray() {
		$this->userprojects = array();
		$this->db = $this->connect();
		$result = $this->readUserProjects();
		while ($row = $result->fetch_assoc()) {
			array_push($this->userprojects, new UserProject($row["emp_id"],$row["p_name"]));
		}
	}

	function getUserProjects() {
		$this->fillArray();  
		return $this->userprojects;
	}

	function readUserProjects(){
		$sql = "SELECT * FROM works_on ";
		$result = $this->db->query($sql);
		if ($result->num_rows > 0){
			return $result;
		}
		else {
			return false;
		}
	}

}