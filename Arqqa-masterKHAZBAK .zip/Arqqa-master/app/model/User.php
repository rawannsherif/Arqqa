<?php
  require_once(__ROOT__ . "model/Model.php");
?>

<?php
class User extends Model {

    protected $id;
    protected $posid;
    protected $fullname;
    protected $username;
    protected $password;
	protected $prj_name;


    function __construct($id="",$posid="",$fullname="",$username="",$password="") {
        $this->id = $id;
        $this->db = $this->connect();
        if(""===$username){
            $this->readUser($id);
        }
        else{
            $this->username = $username;
            $this->password=$password;
            $this->fullname = $fullname;
			$this->prj_name=$prj_name;
        }
             
    }
	
	
    function getID() {
        return $this->id;
    }
    function getPosId(){
        return $this->posid;
    }
    function setPosId($posid){
        return $this->posid=$posid;
    }
    function getFullName(){
        return $this->fullname;
    }
    function setFullName(){
        return $this->fullname=$fullname;
    }
    function getUserName() {
        return $this->username;
    }
    function setUserName($username) {
        return $this->username = $username;
    }
    function getPassword() {
        return $this->password;
    }
    function setPassword($password) {
        return $this->password = $password;
    }

    function Login($username,$password){
        $sql="SELECT * FROM employee WHERE username='$username' AND password='$password' AND deactivate='0'";
        $db = $this->connect();
        $result = $db->query($sql);
        if ($result->num_rows == 1){
            $row = $db->fetchRow();
            $_SESSION["ID"]=$row["id"];
            $_SESSION["username"]=$row["username"];
            echo "<script>alert('Logged in Successfully');</script>";
            $this->acctype = $row['position'];
            if( $this->acctype == '2'){
                echo '<script>window.location.href= "hrmanager.php";</script>';
            }
            else if($this->acctype=='1' ){
                echo '<script>window.location.href= "requests.php";</script>';
            }
            else if($this->acctype=='3' ){
                echo '<script>window.location.href= "pm.php";</script>';
            }
            else{
                echo '<script>window.location.href= "myprojects.php";</script>';
            }
        } 
        else{
            echo "<script>alert('Wrong username or password.');</script>";
        }
    }

    function readUser($id){
        $sql = "SELECT * FROM employee where ID=".$id;
        $db = $this->connect();
        $result = $db->query($sql);
        if ($result==true){
            $row = $db->fetchRow();
            $this->posid=$row["position"];
            $this->username = $row["username"];
            $_SESSION["username"]=$row["username"];
			 $_SESSION["id"]=$row["id"];
            $this->fullname=$row["fullname"];
            $this->password=$row["password"];
			
			echo $_SESSION["id"];
        }
        else{
            $this->username = "";
            $this->fullname="";
            $this->password="";
        }
      } 
	  
	function ViewProjects(){
		$sql = "SELECT * FROM works_on where emp_id=".$_SESSION['ID'];
		$result = $db->query($sql);
        if ($result==true){
			$row = $db->fetchRow();
			$this->prj_name=$row["p_name"];
			
		}
		
		
	}

}
