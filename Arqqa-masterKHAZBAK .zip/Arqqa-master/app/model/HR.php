<?php
require_once(__ROOT__ . "model/Model.php");
require_once(__ROOT__ . "model/Employee.php");

class HR extends Model {
	private $employees;
	function __construct() {
		$this->fillArray();
	}

	function fillArray() {
		$this->employees = array();
		$this->db = $this->connect();
		$result = $this->readEmployees();
		while ($row = $result->fetch_assoc()) {
			array_push($this->employees, new Employee($row["id"]));
		}
	}

	function getEmployees() {
		$this->fillArray();  
		return $this->employees;
	}

	function getEmployee($Emp_id) {
		foreach($this->employees as $employee) {
			if ($Emp_id == $employee->getID()) {
				return $employee;
			}
		}
	}

	function readEmployees(){
		$sql = "SELECT * FROM employee";
		$result = $this->db->query($sql);
		if ($result->num_rows > 0){
			return $result;
		}
		else {
			return false;
		}
	}

	function insertEmployee($fullname,$address,$mobile,$username,$password,$email,$position){
		$sql = "INSERT INTO employee (fullname, address, email,position,username,password,mobile) VALUES ('$fullname', '$address','$email','$position','$username',
		'$password','$mobile')";
		if($this->db->query($sql) === true){
			echo "Records inserted successfully.";
			$this->fillArray();
		} 
		else{
			echo "ERROR: Could not able to execute $sql. " . $conn->error;
		}
	}
	function editEmployee($id,$fullname,$address,$mobile,$username,$password,$email){
		$sql = " UPDATE `employee` SET
	`fullname`='".$fullname."'
	,`address`='".$address."'
	,`mobile`='".$mobile."'
	,`username`='".$username."'
	,`password`='".$password."'
	,`email`='".$email."'
	WHERE `id`='".$id."'";
		if($this->db->query($sql) === true){
			 echo '<script>window.location.href= "hrmanager.php";</script>';
		} else{
			echo "ERROR: Could not able to execute $sql. " . $conn->error;
		}
	}
	function deactivateEmployee($id){
		$sql=" UPDATE `employee` SET
`deactivate`=1 
 WHERE `id`='".$id."'";
		if($this->db->query($sql) === true){
			 echo '<script>window.location.href= "hrmanager.php";</script>';
		} else{
			echo "ERROR: Could not able to execute $sql. " . $conn->error;
		}
	}
	
	function ReadPosition(){
		$arr=array();
		$sql = "SELECT `id`, `type` FROM `positiontype` ";
		if($this->db->query($sql) === true){
			while($row=mysqli_fetch_array($result)) {
      array_push($arr,$row);
   }
   foreach($arr as $rows){
       echo '<option value="'.$rows[0].'">'.$rows[1].'</option>';
   }
    
  }
	else
	{
		echo 'cannot retrieve data';
	}

		
	}
}