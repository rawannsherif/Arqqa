<?php

require_once("C:\wamp64\www\Arqqa-master\app\controller\Controller.php");

class pmController extends Controller{


 	public function edit() {
   $id = $_REQUEST['pid'];
     $name = $_REQUEST['pname'];
    $description = $_REQUEST['pdesc'];
    $mngid = $_REQUEST['mngid'];
    $startDate = $_REQUEST['sd'];
 $endDate = $_REQUEST['ed'];
# $noOfemp = $_REQUEST['name'];;
 #$stateid = $_REQUEST[''];

 		$this->model->editProject($id,$name, $description, $mngid, $startDate,$endDate,$noOfemp="1",$stateid="1");
 	}
  public function insert() {

     $name = $_REQUEST['pname'];
    $description = $_REQUEST['pdesc'];
    $mngid = $_REQUEST['mngid'];
    $startDate = $_REQUEST['sd'];
  $endDate = $_REQUEST['ed'];
  # $noOfemp = $_REQUEST['name'];;
  #$stateid = $_REQUEST[''];

    $this->model->insertProject($name, $description, $mngid, $startDate,$endDate,$noOfemp="1",$stateid="1");
  }
 public function delete(){
      $id = $_REQUEST['id'];
 	$this->model->deleteProject($id);
 	}
 }
 ?>
