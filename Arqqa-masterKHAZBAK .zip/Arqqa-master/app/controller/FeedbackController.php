<?php

require_once(__ROOT__ . "controller/Controller.php");

class FeedbackController extends Controller{
	public function insert() {
		if (isset($_POST['submit'])){
	
	$fullname=$_POST['fullname'];
	$address=$_POST['address'];
	$mobile=$_POST['mobile'];
	$positionT=$_POST['acctype'];
	$username=$_POST['username'];
	$password=$_POST['password'];
	$email=$_POST['email'];
	if($positionT =='Hr Manager'){
		$position='1';
	}
	else if($positionT =='HR Employee')
	{
		$position='2';
	}
	else if($positionT =='Project Manager')
	{
		$position='3';
	}
	else
	{
		$position='4';
	}
	
	
	$this->model->insertEmployee($fullname,$address,$mobile,$username,$password,$email, $position);
		}
	}

	public function edit($movie_id) {
				if (isset($_POST['submit'])){
		$id= $_POST['id'];
	$fullname=$_POST['fullname'];
	$address=$_POST['address'];
	$mobile=$_POST['mobile'];
	
	$username=$_POST['username'];
	$password=$_POST['password'];
	$email=$_POST['email'];
	
	$this->model->editEmployee($id,$fullname,$address,$mobile,$username,$password,$email);
		}
	}

	public function deactivate($Emp_id){
		$this->model->deactivateEmployee($Emp_id);
	}
}
?>
