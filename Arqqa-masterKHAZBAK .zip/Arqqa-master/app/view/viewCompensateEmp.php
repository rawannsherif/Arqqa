<head>
		<link href="public/style.css" rel="stylesheet" type="text/css">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"> </script>
</head>
<?php

require_once(__ROOT__ . "view/View.php");

class viewCompensateEmp extends View{	
	public function output(){
		$str="";
	
		
				$str.="<form action='CompensateEMP.php?action=overtime&id='' method='post'>
				<div class='overtimeDiv'>
						<div class='overtimeDiv2'>";
						
				$str.="<label class='labelEdit'>weekday</label>
						<input class='inputEdit' type='text' value='".$this->model->getWeekndover()."'></div>
						<br>";
						
				$str.="<div class='overtimeDiv3'>";
				
				$str.="<label class='labelEdit'>Night Shift</label>
						<input class='inputEdit' type='text' value='".$this->model->getNightshiftover()."' > <br>";


				$str.="<br><button class='buttonEditEmp' type='button'>Back</button>";
				$str.="<button class='buttonEditEmp' type='button'>Confirm</button></div></div>
				</form>";
	


return $str;
	}
	
	
	public function editForm(){
		$str='<form action="profile.php?action=editaction" method="post">
		<div>Name:</div><div> <input type="text" name="name" value="'.$this->model->getName().'"/></div><br>
		<div>Password:</div><div> <input type="password" name="password" value="'.$this->model->getPassword().'"/></div><br>
		<div>Age:</div><div> <input type="text" name="age" value="'.$this->model->getAge().'"/></div><br>
		<div>Phone: </div><div><input type="text" name="phone" value="'.$this->model->getPhone().'"/></div><br>
		<div><input type="submit" /></div>';
		return $str;
	}
}
?>
