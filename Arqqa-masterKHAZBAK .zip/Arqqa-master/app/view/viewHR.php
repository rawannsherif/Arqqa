<head>
		<link href="public/style.css" rel="stylesheet" type="text/css">
	
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"> </script>
<script>
			$(document).ready(function(){
			$("#remove."<?php echo $id;?>".").click(function(){
			$("#emp-div."<?php echo $id;?>".").hide();
				});
			});
		</script>
		
<script>


</script>

</head>
<?php
require_once(__ROOT__ . "view/View.php");

class ViewHR extends View{

	public function output(){
		$deactivate='0';
		$str = "";
		
		foreach($this->model->getEmployees() as $Employee){
			if($Employee->getDeactivate() == $deactivate){
			
			$str.="<div class='container'>
			<div id='emp-divid".$Employee->getID()."'>
			<div>";
			$str.="<div><img src='".$Employee->getImg() ."' style='width: 50px;height: 50px;border-radius: 52px;background:#fff;border: 1px solid #707070;'></img></div>";
			$str.="<label>Full Name: ". $Employee->getFullName()."</label><br>
					<label>Email: ".$Employee->getEmail()."</label><br>
					<label>Mobile: ".$Employee->getMobile()."</label><br>
					<a href='hrmanager.php?action=edit&id=".$Employee->getID()."' > Update </a>
					<a href='hrmanager.php?action=remove&id=".$Employee->getID()."' > Deactivate </a> 
					<a href='hrmanager.php?action=view&id=".$Employee->getID()."' > View </a> ";
					
			$str.="</div>
			</div>
			</div> </div> <br>";
		}}
		
		
		return $str;
	}
	
	public function editform($id){
		$str = "";
		
		foreach($this->model->getEmployees() as $Employee){
			if($Employee->getID()===$id) 	{
				$str.="<div>";
				
				$str.="<form action='hrmanager.php?action=editAction&id=".$Employee->getID()."' method='post'>";
				//$str.="<div><img src='".$Employee,getImg()."' class='image'></img><button class='Upload'>Upload</button></div>";
				$str.="<div><img class='image'  src='".$Employee->getImg() ."'></img>";
				
				$str.="<input type='hidden' name='id' value='".$Employee->getID() ."'>";
				
				
				
				$str.="<div><label class='labelEdit'>Fullname:</label>
				<input type='text' class='inputEdit' name='fullname' value='". $Employee->getFullName() ."'></div> ";
				
				$str.="<div><label class='labelEdit'>Address:</label>
				<input type='text' class='inputEdit' name='address' value='". $Employee->getAddress() ."'></div> ";
				
				$str.="<div><label class='labelEdit'>Mobile:</label>
				<input type='number' class='inputEdit' name='mobile' value='". $Employee->getMobile() ."'></div> ";
				
				$str.="<div><label class='labelEdit'>Email:</label>
				<input type='text' class='inputEdit' name='email' value='". $Employee->getEmail() ."'></div> ";
				
				$str.="<div><label class='labelEdit'> <label for='Status'>Status:</label></label>
				<select class='inputEdit'id='status'>
						<option value='deactivated'>Deactivated</option>
						<option value='active'>Active</option>
						
					</select>
				</div>";
				
				
				
				$str.="<div><label class='labelEdit'> <label for='position'>Position:</label></label>
				<select name='acctype' class='inputEdit'id='position'>
						<option value='hr-mng'>Hr Manager</option>
						<option value='hr-team'>HR Employee</option>
						<option value='prj-mng'>Project Manager</option>
						<option value='prj-eam'>Employee</option>
					</select>
				</div>";
				
				$str.="<div><label class='labelEdit'>Salary:</label>
				<input type='text' class='inputEdit' name='salary' value='". $Employee->readSalary('1') ."'></div> ";
				
				$str.="<div><label class='labelEdit'>UserName:</label>
				<input type='text' class='inputEdit' name='username' value='". $Employee->getUserName() ."'></div> ";
				
				$str.="<div><label class='labelEdit'>Password:</label>
				<input type='text' class='inputEdit' name='password' value='". $Employee->getPassword() ."'></div> ";
								
				$str.="<div><a href='hrmanager.php?action=back'><button class='buttonEditEmp' name='back'>Back</button></a>
				<button type='submit' class='buttonEditEmp' name='submit'>Confirm</button><br><br><br></div> ";
				
				$str.="</form>
		</div>";
		
		
			}
			
		}
		
		return $str;
	}
	
	public function view($id){
		$str = "";
		
		foreach($this->model->getEmployees() as $Employee){
			if($Employee->getID()===$id) 	{
				$str.="<div>";
				
				$str.="<form action='hrmanager.php?action=overtime&id=".$Employee->getID()."' method='post'>";
				//$str.="<div><img src='".$Employee,getImg()."' class='image'></img><button class='Upload'>Upload</button></div>";
				$str.="<div><img class='image'  src='".$Employee->getImg() ."'></img>";
				$str.="<button type='submit' class='overtime' style='top:0.5%; left: 3%;'>overtime</button></div>";
				
				$str.="<input type='hidden' name='id' value='".$Employee->getID() ."'>";
				
				
				
				$str.="<div><label class='labelEdit'>Fullname:</label>
				<input type='label' class='inputEdit' name='fullname' value='". $Employee->getFullName() ."'></div> ";
				
				$str.="<div><label class='labelEdit'>Address:</label>
				<input type='text' class='inputEdit' name='address' value='". $Employee->getAddress() ."'></div> ";
				
				$str.="<div><label class='labelEdit'>Mobile:</label>
				<input type='number' class='inputEdit' name='mobile' value='". $Employee->getMobile() ."'></div> ";
				
				$str.="<div><label class='labelEdit'>Email:</label>
				<input type='text' class='inputEdit' name='email' value='". $Employee->getEmail() ."'></div> ";
				
				$str.="<div><label class='labelEdit'> <label for='Status'>Status:</label></label>
				<select class='inputEdit'id='status'>
						<option value='deactivated'>Deactivated</option>
						<option value='active'>Active</option>
						
					</select>
				</div>";
				
				
				
				$str.="<div><label class='labelEdit'> <label for='position'>Position:</label></label>
				<select name='acctype' class='inputEdit'id='position'>
						<option value='hr-mng'>Hr Manager</option>
						<option value='hr-team'>HR Employee</option>
						<option value='prj-mng'>Project Manager</option>
						<option value='prj-eam'>Employee</option>
					</select>
				</div>";
				
				$str.="<div><label class='labelEdit'>Salary:</label>
				<input type='text' class='inputEdit' name='salary' value='". $Employee->readSalary('1') ."'></div> ";
				
				$str.="<div><label class='labelEdit'>UserName:</label>
				<input type='text' class='inputEdit' name='username' value='". $Employee->getUserName() ."'></div> ";
				
				$str.="<div><label class='labelEdit'>Password:</label>
				<input type='text' class='inputEdit' name='password' value='". $Employee->getPassword() ."'></div> ";
								
				$str.="<div><a href='hrmanager.php?action=back'><button class='buttonEditEmp' name='back'>Back</button></a>";
				
				$str.="</form>
		</div>";
		
	
		
			}
			
		}
		
		return $str;
	}
	
	public function overtime($id){
		
		$str="";
		
		foreach($this->model->getEmployees() as $Employee){
			if($Employee->getID()===$id){
		
				$str.="<form action='CompensateEMP.php?action=overtime&id=".$Employee->getID()."' method='post'>
				<div class='overtimeDiv'>
						<div class='overtimeDiv2'>";
						
				$str.="<label class='labelEdit'>weekday</label>
						<input class='inputEdit' type='text' value='".$Employee->comp_emp->getWeekndover()."'></div>
						<br>";
						
				$str.="<div class='overtimeDiv3'>";
				
				$str.="<label class='labelEdit'>Night Shift</label>
						<input class='inputEdit' type='text' value='".$Employee->comp_emp->getNightshiftover()."' > <br>";


				$str.="<br><button class='buttonEditEmp' type='button'>Back</button>";
				$str.="<button class='buttonEditEmp' type='button'>Confirm</button></div></div>
				</form>";
	

}}
	return $str;
	}
	
	public function addform(){
		$str = "";
			$str.="<div>";
				
				$str.="<form action='hrmanager.php?action=insertAction' method='post'>";
				//$str.="<div><img src='".$Employee,getImg()."' class='image'></img><button class='Upload'>Upload</button></div>";
				$str.="<div><img class='image' name='image' src=''></img><button class='Upload'>Upload</button></div>";
				
				$str.="<input type='hidden' name='id' value=''>";
				
				
				
				$str.="<div><label class='labelEdit'>Fullname:</label>
				<input type='text' class='inputEdit' name='fullname' value=''></div> ";
				
				$str.="<div><label class='labelEdit'>Address:</label>
				<input type='text' class='inputEdit' name='address' value=''></div> ";
				
				$str.="<div><label class='labelEdit'>Mobile:</label>
				<input type='number' class='inputEdit' name='mobile' value=''></div> ";
				
				$str.="<div><label class='labelEdit'>Email:</label>
				<input type='text' class='inputEdit' name='email' value=''></div> ";
				
				$str.="<div><label class='labelEdit'> <label for='Status'>Status:</label></label>
				<select class='inputEdit'id='status'>
						<option value='deactivated'>Deactivated</option>
						<option value='active'>Active</option>
						
					</select>
				</div>";
				
				
				
				$str.="<div><label class='labelEdit'> <label for='position'>Position:</label></label>
				<select class='inputEdit'id='position'>
						<option value='hr-mng'>Hr Manager</option>
						<option value='hr-team'>HR Employee</option>
						<option value='prj-mng'>Project Manager</option>
						<option value='prj-eam'>Employee</option>
					</select>
				</div>";
				
				
				$str.="<div><label class='labelEdit'>UserName:</label>
				<input type='text' class='inputEdit' name='username' value=''></div> ";
				
				$str.="<div><label class='labelEdit'>Password:</label>
				<input type='text' class='inputEdit' name='password' value=''></div> ";
								
				$str.="<div><a href='hrmanager.php?action=back'><button class='buttonEditEmp' name='back'>Back</button></a>
				<button type='submit' class='buttonEditEmp' name='submit'>Confirm</button><br><br><br> ";
				
				$str.="</form>
		</div>";
		
		
		
		return $str;
		
		
	}
}
?>