<head>
		<link href="public/style.css" rel="stylesheet" type="text/css">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"> </script>
<script>

			function myFunction() {

			var s = document.getElementById("feedbackdiv");
			if (s.style.display === "none") {
				s.style.display = "block";
			} 
			}
			function myFunction2() {
			var h = document.getElementById("feedbackdiv");
			if (h.style.display === "block") {
				h.style.display = "none";
			} 
			}
		</script>
		<script>
			var slider = document.getElementById("myRange");
			var output = document.getElementById("demo");
			output.innerHTML = slider.value;
			slider.oninput = function() {
			output.innerHTML = this.value;
			}
		</script>
</head>
<?php
require_once(__ROOT__ . "view/View.php");

class viewFeedback extends View{

	public function output(){
		
		$str = "";
		
		foreach($this->model->getfeedbacks() as $Feedback){
			echo $Feedback->getEmpID();
			
			$str.="
		<div class='container' >
			<div style=''>
			<div id='emp-divid".$Feedback->getEmpID()."'>
			";
			$str.="<label class='text'>Project Manger's Name: ".$Feedback->getManagerName()."</label><br>";
			$str.="<label class='text'>Projects Name: ".$Feedback->getPrjName()."<label><br>";
					
			$str.="<div><label class='text'> Employee's Name: ".$Feedback->getEmpName()."</label></div>";
			$str.="<div style='text-align:center'>
			<a href='feedbacks.php?action=view&id=".$Feedback->getEmpID()."' class='buttonfeed'> View Feedback </a> 
				</div>";
			
			$str.="</div>
		</div>";
				
				
				
		}
		
		
		return $str;
	}
	
	
	public function feedbackview($id){
		
		$strr = "";
		
		foreach($this->model->getfeedbacks() as $Feedback){
			
			if($Feedback->getEmpID()===$id) 	{
				
		
		$strr.=" <div >
			<div >
			
				<label class='labelfeedback'>Feedback</label>
				<div class='print' >".$Feedback->getName()."
				</div>
			</div>";
			
			$strr.="<h3 class='feedbackdiv'>performance rating:</h3>
				<div class='slidecontainerfeedbacks' style=''>
					<input type='range' min='1' max='10' value='".$Feedback->getPerformance()."' class='slider' id='myRange'>
					<p style='position: relative;top: 270px;'>Value: <span id='demo'></span></p>
				</div>
			<a href='feedbacks.php'>'<button type='button' class='back'>Back</button></a>
		</div>";
	}

	
	
}
		
	return $strr;
	
}}
?>