<?php
require_once("C:/wamp64\www/Arqqa-master/app/view/View.php");

class ViewPm extends View{
	public function output(){
$str="<include src='C:/wamp64/www/Arqqa-master1/includes/pmheader.html'></include>
<div class='projects'>";
    foreach($this->model->getProjects() as $project){
     $str=$str.'<div onclick="location.href ="pm.php?action=view&name='.$project->getName().'";"">
			 <a style="text-decoration: none; " href="pm.php?action=view&name='.$project->getName().'">
       <div><div>
       <form id="form" method="POST" action="pm.php">
<input type="hidden" name="id" value='.$project->getName().'>
<input type="image" formaction="pm.php?action=ediit&name='.$project->getName().'"class="editiconp" src="https://img.icons8.com/ios/50/000000/edit.png"/>
			 <input type="image" formaction="pm.php?action=delete&name='.$project->getName().'" class="removeiconp" src="https://img.icons8.com/ios/50/000000/cancel.png">
	 </form></div>';
       $str=$str."<label class='title'>Projects Name:".$project->getName()."</label><BR>"."<label class='mintitle'>Project Manager's Name:".$project->getMngID()."</label><br>";
  $str=$str."<label class='mintitle'>Due Date:".$project->getendd()."</label><br>";
  $str=$str." </div>
    <div class='linepp'></div>
    <div class='Progressbar'>
        <div class='progress'style='width:60%''>60%</div>
      </div></a>
    </div>
	";
}
$str=$str."	<button
  form='form'formaction='pm.php?action=insert' class='createprojectp'>Create Project</button>
		<button form='form'formaction='login.php'class='logoutp'>Log Out</button>  </div>";
return $str;
}

public function editproject($name){
	$str="";

		#foreach if id
		foreach($this->model->getProjects() as $project){

			if($project->getName()===$name){

    $str=$str."<div style='width: 1151px;
    position: relative;
    left: 360px;
    top: 35px;
'><form action='pm.php' method='post'>
		<input class='inputp' type='hidden' id='pid' name='pid' value='".$project->getName()."'>";
  $str=$str.="<div>  <label class='formL'>Project's Name:</label>";
  $str=$str."<input class='inputp' type='text' id='pname' name='pname' value='".$project->getName()."'> </div><br>";
  $str=$str."<div><label class='formL'>Project Description:"."</label>
      <input class='inputp' type='text' id='pdesc' name='pdesc' value=".$project->getDesc()."></div> <br>";
  $str=$str."<div><label class='formL'>Project Manager:</label>"."
      <input class='inputp' type='text' id='pmng' name='mngid' value=".$project->getMngID()."></div> <br>";

  $str=$str."<div> <label class='formL'>Start Date:</label>"."
      <input class='inputp' type='date' id='sdate' name='sd' value=".$project->getstartd()."></div><br>";
  $str=$str."<div><label class='formL'>End Date:</label>"."
      <input class='inputp' type='date' id='edate' name='ed' value=".$project->getendd()."></div><br>
    <button type='button'onclick='editselectemployee()'class='adde'>Add new Employee</button>";
  $str=$str."<input style='    left: 400px;
	top: 233px;'class='confirmpform' name ='confirmedit'type='submit' value='confirm'/>";
    #<a href='projectmanager.html'><button class="createproject" style="
    #    position: relative;
    #    left: -768px;
    #    /* right: 23px; */
    #">back</button></a>
    $str=$str."<button  formaction='pm.php?action='class='createprojectp' style='
		    position: relative;
		    left: -768px;
		    top: 233px;
		'>back</button></form></div>

		<div style='display:none;position: fixed;
		'id='p-div'>	<div class='containerp'>";
		foreach($this->model->getEmployees() as $emp){
	$str=$str."
		<div>



		<div>
		<img src='background.png'style='width: 60px;height: 60px;border-radius: 52px;background:#fff;border: 1px solid #707070;position: relative;
    bottom: 7px;
    left: 2px;'></img>
		<div style='position: relative;
		    left: 68px;

		    bottom: 66px;'>
		<label>Full Name: ".$emp->getName()."</label><br>
		  <label>Department:"."</label><br>
		  <label>Mobile:".$emp->getPhone()."</label><br></div>
		  <div class='linep'></div>
		  </div>
		  <div>
		  <input style='width: 30px;
		height: 30px;
		border-radius: 4px;
		background: transparent;
		border: 3px solid #a31919;position: relative;
		    bottom: 42px;
		'type='checkbox'>
		  </div>
		</div>



		";}
		$str=$str."</div><div>
		<button onclick='hideeditselectemployee()'style='width: 280px;
		height: 81px;
		background: #fff;
		border-radius:4px;
		font-family: Helvetica;
		font-weight: bold;
		font-size: 16px;
		line-height: 20px;
		text-align: center;
		color: #100e0e;
		    position: relative;
			    left: 142px;
		    top: -254px;
		'>back</button>
		<button style='width: 280px;
		height: 81px;
		background: #fff;
		border: 2px solid #fe0303;
		font-family: Helvetica;
		font-weight: bold;
		font-size: 16px;
		line-height: 20px;
		text-align: center;
		color: #a31919;
		    position: relative;
		    left:839px;
		    top: -254px;
		'>confirm</button>
		</div>
		</a>
		</div>";}

}
return $str;

}
public function addproject(){
	$str="";

		$str=$str."<div style='width: 1151px;
		position: relative;
		left: 360px;
		top: 35px;
'><form action='pm.php' method='post'>
	";
	$str=$str.="<div>  <label class='formL'>Project's Name:</label>";
	$str=$str."<input class='inputp' type='text' id='pname' name='pname' > </div><br>";
	$str=$str."<div><label class='formL'>Project Description:"."</label>
			<input class='inputp' type='text' id='pdesc' name='pdesc' ></div> <br>";
	$str=$str."<div><label class='formL'>Project Manager:</label>"."
			<input class='inputp' type='text' id='pmng' name='mngid' ></div> <br>";

	$str=$str."<div> <label class='formL'>Start Date:</label>"."
			<input class='inputp' type='date' id='sdate' name='sd' ></div><br>";
	$str=$str."<div><label class='formL'>End Date:</label>"."
			<input class='inputp' type='date' id='edate' name='ed' ></div><br>
		<button type='button'onclick='editselectemployee()'class='adde'>Add new Employee</button>";
	$str=$str."<input style='    left: 400px;
	top: 233px;'class='confirmpform' name ='confirmadd'type='submit' value='confirm'/>";
		#<a href='projectmanager.html'><button class="createproject" style="
		#    position: relative;
		#    left: -768px;
		#    /* right: 23px; */
		#">back</button></a>
		$str=$str."<button  formaction='pm.php?action='class='createprojectp' style='
				position: relative;
				left: -768px;
				top: 233px;
		'>back</button></form></div>

		<div style='display:none;position: fixed;
		'id='p-div'>	<div class='containerp'>";
		foreach($this->model->getEmployees() as $emp){
	$str=$str."
		<div>



		<div>
		<img src='background.png'style='width: 60px;height: 60px;border-radius: 52px;background:#fff;border: 1px solid #707070;position: relative;
		bottom: 7px;
		left: 2px;'></img>
		<div style='position: relative;
				left: 68px;

				bottom: 66px;'>
		<label>Full Name: ".$emp->getName()."</label><br>
			<label>Department:"."</label><br>
			<label>Mobile:".$emp->getPhone()."</label><br></div>
			<div class='linep'></div>
			</div>
			<div>
			<input style='width: 30px;
		height: 30px;
		border-radius: 4px;
		background: transparent;
		border: 3px solid #a31919;position: relative;
				bottom: 42px;
		'type='checkbox'>
			</div>
		</div>



		";}
		$str=$str."</div><div>
		<button onclick='hideeditselectemployee()'style='width: 280px;
		height: 81px;
		background: #fff;
		border-radius:4px;
		font-family: Helvetica;
		font-weight: bold;
		font-size: 16px;
		line-height: 20px;
		text-align: center;
		color: #100e0e;
				position: relative;
					left: 142px;
				top: -254px;
		'>back</button>
		<button style='width: 280px;
		height: 81px;
		background: #fff;
		border: 2px solid #fe0303;
		font-family: Helvetica;
		font-weight: bold;
		font-size: 16px;
		line-height: 20px;
		text-align: center;
		color: #a31919;
				position: relative;
				left:839px;
				top: -254px;
		'>confirm</button>
		</div>
		</a>
		</div>";


return $str;
}

public function viewproject($name){
	$str="";


		foreach($this->model->getProjects() as $project){
			
			if($project->getName()===$name){

    $str=$str."<div style='width: 1151px;
    position: relative;
    left: 360px;
    top: 35px;
''><form action='pm.php' method='post'>
		<input  type='hidden' id='pid' name='pid' value='".$project->getName()."'>";
  $str=$str.="<div>  <label class='formL'>Project's Name:</label>";
  $str=$str."<input disabled style='margin-left: 4px;' class='inputp' type='text' id='pname' name='pname' value='".$project->getName()."'> </div><br>";
  $str=$str."<div><label class='formL'>Project Description:"."</label>
      <input disabled class='inputp' type='text' id='pdesc' name='pdesc' value=".$project->getDesc()."></div> <br>";
  $str=$str."<div><label class='formL'>Project Manager:</label>"."
      <input disabled class='inputp' type='text' id='pmng' name='mngid' value=".$project->getMngID()."></div> <br>";

  $str=$str."<div> <label class='formL'>Start Date:</label>"."
      <input disabled class='inputp' type='date' id='sdate' name='sd' value=".$project->getstartd()."></div><br>";
  $str=$str."<div><label class='formL'>End Date:</label>"."
      <input disabled class='inputp' type='date' id='edate' name='ed' value=".$project->getendd()."></div><br>";

   
    $str=$str."<button formaction='pm.php?action='class='createprojectp' style='
		    position: relative;
				left: -1px;

		    top: 269px;
		'>back</button></form></div>";}

}
return $str;

}




}

?>
