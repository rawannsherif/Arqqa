<?php
require_once(__ROOT__ . "view/View.php");

class viewUser extends View{

	public function output(){
		
		$str = "<div  style=' position: relative;left: 24px; top: 16px;width: 604px;'>
		
			<a href='myprojects.php'> <button class='activebutton' style='background: #fe0303;' name = 'myprojects'> My Projects </button></a>
			<a href='myprojects.php?action=feedbacks'>  <button  class='buttonnav' name = 'myfeedback'> My Feedback </button></a>
			<a href='myprojects.php?action=salary'>  <button class='buttonnav'  name = 'viewsalary'> View Salary </button></a>
			<a href='myprojects.php?action=info'> <button class='buttonnav'  name = 'myinfo'> My Info </button></a>
			
		</div>";
		
		$id=$_SESSION["ID"];
		
		foreach($this->model->getUserProjects() as $UserProject){
			
			if($UserProject->getID()===$id) {
			
	$str.="<div class='projects'>
	<div>
		<div>
			<br>
			<label class='Ptitle'>Project's Name:".$UserProject->getName()."</label>
			<br>
			<br>
			<label class='mintitle'>Project Manager's Name:".$UserProject->getManagerNameP()."</label>
			<br>
			<label class='mintitle'>Due Date:".$UserProject->getDueDate()."</label>
			<br>
		</div>
		
	<br>
	
		<div class='line'>
			<div class='myProgress'>
				<div class='myBar' style=;width:60%'>60%</div>
			</div>
		</div>

</div>
</div>
<br>
";}
		}
		return $str;
	}
	
	
	
	





	 function Feedback(){
		$str = "<div  style=' position: relative;left: 24px; top: 16px;width: 604px;'>
		
			<a href='myprojects.php'> <button class='buttonnav' style='' name = 'myprojects'> My Projects </button></a>
			<a href='myprojects.php?action=feedbacks'>  <button  class='activebutton' name = 'myfeedback'> My Feedback </button></a>
			<a href='myprojects.php?action=salary'>  <button class='buttonnav'  name = 'viewsalary'> View Salary </button></a>
			<a href='myprojects.php?action=info'> <button class='buttonnav'  name = 'myinfo'> My Info </button></a>
			
		</div>";
		
		$id=$_SESSION["ID"];
		
		return $str;
		
	}
	

}?>