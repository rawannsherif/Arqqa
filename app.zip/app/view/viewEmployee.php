<head>
		<link href="public/style.css" rel="stylesheet" type="text/css">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"> </script>
</head>
<?php

require_once(__ROOT__ . "view/View.php");

class ViewEmployee extends View{	
	public function output(){
		$str = "";
		$str.="<a href='profile.php'>Back to Profile </a>";
		$str.="<table>";
		$str.="<tr><th>Name</th><th>Year</th><th>Update</th><th>Remove</th></tr>";
		foreach($this->model->getMovies() as $Movie){
			$str.="<tr>";

			$str.="<td>".$Movie->getName() ."  </td> ";
			$str.="<td>" . $Movie->getYear() ."</td> ";
			$str.="<td><a href='Movies.php?action=edit&id=".$Movie->getID() ."'>Edit Movie </a></td>";
			$str.="<td><a href='Movies.php?action=delete&id=".$Movie->getID() ."'>Remove Movie </a></td>";
			
		
			$str.="</tr>";
		}
		$str.="<a href='Movies.php?action=insert>Add Movie</a>";
		$str.="</table>";
		
		return $str;
	}
	
	
	public function editForm(){
		$str='<form action="profile.php?action=editaction" method="post">
		<div>Name:</div><div> <input type="text" name="name" value="'.$this->model->getName().'"/></div><br>
		<div>Password:</div><div> <input type="password" name="password" value="'.$this->model->getPassword().'"/></div><br>
		<div>Age:</div><div> <input type="text" name="age" value="'.$this->model->getAge().'"/></div><br>
		<div>Phone: </div><div><input type="text" name="phone" value="'.$this->model->getPhone().'"/></div><br>
		<div><input type="submit" /></div>';
		return $str;
	}
}
?>
