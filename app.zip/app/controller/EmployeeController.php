<?php

require_once(__ROOT__ . "controller/Controller.php");

class EmployeeController extends Controller{
	public function login(){
		if (isset($_POST['submit'])){
		$username= $_POST['username'];
		$password=$_POST['password'];
		$this->model->login($username,$password);
		}
	}
	public function insert() {
		$name = $_REQUEST['name'];
		$password = $_REQUEST['password'];
		$age = $_REQUEST['age'];
		$phone = $_REQUEST['phone'];

		$this->model->insertUser($name,$password,$age,$phone);
	}

	public function edit() {
		$name = $_REQUEST['name'];
		$password = $_REQUEST['password'];
		$age = $_REQUEST['age'];
		$phone = $_REQUEST['phone'];

		$this->model->editUser($name,$password,$age,$phone);
	}
	
	public function delete(){
		$this->model->deleteUser();
	}
}
?>
