<?php
require_once(__ROOT__ . "model/Model.php");
require_once(__ROOT__ . "model/Employee.php");

class HR extends Model {
	private $employees;
	function __construct() {
		$this->fillArray();
	}

	function fillArray() {
		$this->employees = array();
		$this->db = $this->connect();
		$result = $this->readEmployees();
		while ($row = $result->fetch_assoc()) {
			array_push($this->employees, new employee($row["ID"]));
		}
	}

	function getEmployees() {
		$this->fillArray();  
		return $this->employees;
	}

	function getEmployee($Emp-id) {
		foreach($this->employees as $employee) {
			if ($Emp_id == $employee->getID()) {
				return $movie;
			}
		}
	}

	function readEmployees(){
		$sql = "SELECT * FROM employee where id=".$_SESSION['ID'];
		$result = $this->db->query($sql);
		if ($result->num_rows > 0){
			return $result;
		}
		else {
			return false;
		}
	}

	function insertEmployee($name, $year){
		$sql = "INSERT INTO employee (id, name, year) VALUES ('".$_SESSION['ID']."','$name', '$year')";
		if($this->db->query($sql) === true){
			echo "Records inserted successfully.";
			$this->fillArray();
		} 
		else{
			echo "ERROR: Could not able to execute $sql. " . $conn->error;
		}
	}
}