<?php
  require_once(__ROOT__ . "model/Model.php");
?>

<?php
class Employee extends Model {
  protected $id;
  protected $posid;
  protected $fullname;
  protected $username;
  protected $password;
  protected $email;
  protected $img;
  protected $mobile;
    

  function __construct($id="",$posid="",$fullname="",$username="",$password="",$email="",$img="",$mobile="") {
   $this->id = $id;
		$this->db = $this->connect();

		if(""===$username){
			$this->readEmployee($id);
		}
		else{
      $this->username = $username;
	  $this->password=$password;
      $this->fullname = $fullname;
      $this->mobile = $mobile;
	  $this->posid=$posid;
    }
		
	}

  function getPosId(){
    return $this->posid;
  }
  function setPosId($posid){
    return $this->posid=$posid;
  }
  function getFullName(){
    return $this->fullname;
  }
  function setFullName(){
    return $this->fullname=$fullname;
  }
  function getUserName() {
    return $this->username;
  }
  function setUserName($username) {
    return $this->username = $username;
  }
  function getPassword() {
    return $this->password;
  }
  function setPassword($password) {
    return $this->password = $password;
  }
  function getEmail() {
    return $this->email;
  }
  function setEmail($email) {
    return $this->email = $email;
  }
  function getImg() {
    return $this->img;
  }
  function setImg($img) {
    return $this->img = $img;
  }
  function getMobile(){
    return $this->mobile;
  }
  function setMobile($mobile){
    return $this->mobile=$mobile;
  }
  function getID() {
    return $this->id;
  }

  function Login($username,$password){
    
  $sql="SELECT * FROM employee WHERE username='$username' AND password='$password' AND deactivate='0'";
  $db = $this->connect();
    $result = $db->query($sql);
    if ($result->num_rows == 1){
    $row = $db->fetchRow();
    echo "<script>alert('Logged in Successfully');</script>";
    $this->acctype = $row['position'];
    if( $this->acctype == '2'){
      echo '<script>window.location.href= "hrmanager.php";</script>';
    }
    else if($this->acctype=='1' ){
      echo '<script>window.location.href= "requests.php";</script>';
    }
    else if($this->acctype=='3' ){
      echo '<script>window.location.href= "Projectmanager.php";</script>';
    }
    else{
      echo '<script>window.location.href= "myprojects.php";</script>';
    }
  }
    
  else
  {
    echo "<script>alert('Wrong username or password.');</script>";
  }
}
    
  
  function readEmployee($id){
    $sql = "SELECT * FROM employee where ID=".$id;
    $db = $this->connect();
    $result = $db->query($sql);
    if ($result->num_rows == 1){
        $row = $db->fetchRow();
        $this->posid=$row["position"];
        $this->username = $row["username"];
        $_SESSION["username"]=$row["username"];
        $this->fullname=$row["fullname"];
        $this->password=$row["password"];
        $this->email=$row["email"];
        $this->img=$row["img"];
        $this->mobile = $row["mobile"];
		$this->id=$row["id"];
    }
    else {
        $this->username = "";
        $this->fullname="";
        $this->password="";
        $this->email="";
        $this->img="";
        $this->mobile = "";
    }
  }
  
  
  
  
}

?>s